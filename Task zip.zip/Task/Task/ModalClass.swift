//
//  ModalClass.swift
//  Task
//
//  Created by apple on 13/03/20.
//  Copyright © 2020 apple. All rights reserved.
//


//MARK: - API FOR DATA

let PLACES_DESCRIPTION_API = "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json"

